fig = fig + 1;
figure(fig);
clf;axis equal; hold on;